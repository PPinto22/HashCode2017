public class Requests {
  public Video v;
  public Endpoint e;
  public int N;

  public Requests(Video v, Endpoint e, int n) {
    this.v = v;
    this.N = n;
    this.e = e;
  }

}
